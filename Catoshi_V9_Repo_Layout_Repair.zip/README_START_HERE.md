# Catoshi V9 — root-layout repair + classic homepage + Multiplayer

This package fixes the V8 installation mistake: the previous installer expected `integration/`, `catoshi-classic-home.css`, and `mp/` in a layout that was not actually present in the repository after uploading. **Do not run the old `restore-and-integrate.cjs`.**

## Safe installation in GitHub Codespaces / your repository sandbox

Work on a new branch and keep a clean commit first. Place the **ZIP file itself** at the Catoshi repository root (beside `index.html` and `package.json`); do not upload all its individual files via the browser's flat file upload.

```bash
# From the repository root:
unzip -n Catoshi_V9_Repo_Layout_Repair.zip -d .
node install-catoshi-v9.cjs --check
# Read the output. If the check says BLOCKED, STOP without applying.
node install-catoshi-v9.cjs --apply
npm install
npm test
npm run test:multiplayer
git diff --check
git status --short
```

**Do not commit or deploy until every test succeeds.** Review the diff and commit the installed files (not just the ZIP). After the successful install you can remove the ZIP from the working tree if it was uploaded for installation only.

## Expected tree

```
Catoshi-Vault-Rush/
  index.html                      <-- original, carefully patched only on --apply
  server.cjs                      <-- original, carefully patched only on --apply
  styles.css                      <-- NEVER edited
  game.js                         <-- NEVER edited
  package.json                    <-- adds socket.io if missing and test:multiplayer
  catoshi-classic-home.css        <-- restored classic lobby look, external overlay
  mp-tab.js                       <-- third tab controller, iframe only
  mp-bridge.cjs                    <-- isolated multiplayer child + same-origin proxy
  install-catoshi-v9.cjs          <-- --check or --apply
  mp/
    multiplayer-server.cjs        <-- FREE standalone multiplayer engine
    multiplayer.html
    multiplayer.js
    multiplayer-game.js
    race-engine.js
    race-tracks.js
    ... assets and tests ...
```

The old root `restore-and-integrate.cjs` is obsolete. `node integration/restore-and-integrate.cjs` will fail if the file is not in that directory. **V9 uses only `node install-catoshi-v9.cjs` from the root.**

## What V9 fixes

- Restores the classic brown rounded homepage card and compact tabs without overwriting the original `styles.css`.
- Inserts MULTIPLAYER beside SPEED TRIALS, with racing loaded in an isolated iframe on the **same URL**.
- Provides bot racing, multiplayer matchmaking, friend invite code links (`?race=`), 10 tracks, 3 collectible boosts and coin shooting with a 3.5-second cooldown.
- Restores correct `mp/` file placement and the root test script; duplicate misplaced multiplayer test files are backed up before removal **only if byte-for-byte identical** to the bundled dedicated test. `game.js` and normal solo test files are never deleted.
- The proxy ignores unrelated WebSocket traffic. A multiplayer child crash can return 503 without taking down the solo request handler. This does not isolate container-wide memory or Railway host failures.
- Adds a `test:multiplayer` script to `package.json` but preserves existing scripts.

## Railway

The existing site/domain and Railway service stay as they are. Keep `PUBLIC_ORIGIN=https://vaultrush.catoshirush.fun`, `DATABASE_PATH`, `/data` volume, and the public `PORT` unchanged. The multiplayer child uses an internal port 3001; **do not point Railway public port to 3001**.

**Check the Dockerfile:** if you use a custom Dockerfile it must install production dependencies including `socket.io`. V9 intentionally does not edit Dockerfile automatically. The V9 `--check` command warns if it sees no `RUN npm install` or `RUN npm ci`. If warned, review the Dockerfile before deployment.

After deployment verify:

- `/` serves solo and Speed Trials and shows the 3-part classic tab bar.
- `/catoshi-classic-home.css` and `/mp-tab.js` both respond HTTP 200.
- `/mp/health` returns `{ "ok": true }` (not a 503); otherwise check Railway logs for `[multiplayer]` and verify npm dependencies and database permissions.
- Two browsers can matchmake and play together, bot mode works, and an invited friend can join using `?race=`.

## Rollback and safety

The installer first validates expected landmarks in the HTML and server source. It refuses unknown layouts. On application it creates timestamped backups in `.catoshi-mp-backups/` (gitignored). Review `git diff` before committing. The install is idempotent. It copies missing `mp/` files but does not overwrite existing race code; if your repo already has customised `mp/`, compare carefully.

This version was tested against **locally available** Catoshi source snapshots and a simulation of the misplaced root-test problem. Access to your current private GitHub checkout was unavailable here, so `--check` is essential: a PASS on our snapshots is not a guarantee the current repository layout matches.
