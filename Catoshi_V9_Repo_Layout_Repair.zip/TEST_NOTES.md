# Tests run during V9 packaging

- `node --check install-catoshi-v9.cjs`
- `node --check mp-bridge.cjs`
- Clean source snapshot: `--check`, `--apply`, re-check (idempotence)
- Earlier V18 source snapshot: `--check`, `--apply`, re-check
- Simulated flat upload: `isolation.test.cjs` and `inpage.test.cjs` at repo root were recognized, backed up and removed; `game.js` remained unchanged
- `npm run test:multiplayer`: 15 passed, 0 failed
- Simulated repo `npm test` using Node's auto-discovery after recovery: 15 passed, 0 failed

Not verified: current private GitHub checkout, live Railway deployment, production WebSocket joins, all device/browser conditions. No production changes made.
